/*
Name: Shruti Sharma
Class/Section: CSE 143/Section AR
Date: 18/10/2018

This class keeps track of a game of assassin - which player is stalking who and
who was killed by who.
*/
import java.util.*;

public class AssassinManager {
   
   private AssassinNode killRingFront; // Reference to the kill ring
   private AssassinNode graveyardFront; // Reference to the graveyard 
      
   /*
   * pre: throws IllegalArgumentException if the list of players passed in is empty.
   * post: Takes in a list of names of the players. 
   *       Constructs a kill ring.
   */
   public AssassinManager(List<String> names){
      if(names.isEmpty()){
         throw new IllegalArgumentException();
      }
      killRingFront = new AssassinNode(names.get(0));
      AssassinNode current = killRingFront;
      for(int i = 1; i < names.size(); i++){
         current.next = new AssassinNode(names.get(i));
         current = current.next;
      }
   }
   
   /*
   * post: prints the names of players in the kill ring, indicating who is stalking who.
   */
   public void printKillRing(){
      if(killRingFront.next == null){
         System.out.println("    " + killRingFront.name +
         " is stalking " + killRingFront.name);
      } else {
         AssassinNode current = killRingFront;
         while(current.next != null){
            System.out.println("    " + current.name +
            " is stalking " + current.next.name);
            current = current.next;
         }
         System.out.println("    " + current.name +
         " is stalking " + killRingFront.name);
      }
   }
   
   /*
   * post: Prints the names of players in the graveyard, indicating who was killed by who.
   *       Prints the most recently killed player first.
   */
   public void printGraveyard(){
      AssassinNode current = graveyardFront;
      if(graveyardFront != null){
         while(current != null){
            System.out.println("    " + current.name +
            " was killed by " + current.killer);
            current = current.next;
         }
      }
   }
   
   /*
   * post: Takes in the name of a player as parameter.
   *       Returns true if kill ring contains name, false otherwise.
   *       Ignores case of name.
   */
   public boolean killRingContains(String name){
      AssassinNode current = killRingFront;
      return checkIfNameExists(name, current);
   }
   
   /*
   * post: Takes in the name of player as parameter.
   *       Returns true if graveyard contains name, false otherwise.
   *       Ignores case of name.
   */
   public boolean graveyardContains(String name){
      AssassinNode current = graveyardFront;
      return checkIfNameExists(name, current);
   }
   
   /*
   * post: Takes in name of player and an assassin node (as reference to the list) as parameters.
   *       Returns true if given name exists in the list, false otherwise.
   *       Ignores case of name.
   */
   private boolean checkIfNameExists(String name, AssassinNode current) {
      name = name.toLowerCase();
      while(current != null){
         if(current.name.toLowerCase().equals(name)){
            return true;
         }
         current = current.next;
      }
      return false;
   }
   
   /*
   * post: Returns true if the game is over and false otherwise.
   */
   public boolean gameOver(){
      if(killRingFront.next != null) {
         return false;
      }
      return true;
   }
   
   /*
   * post : Returns the name of player who won the game, if game is over.
   *        Returns null if game is not over.
   */
   public String winner(){
      if(!gameOver()){
         return null;
      } else {
         return killRingFront.name;
      }
   }
   
   /*
   * pre : Throws IllegalArgumentException if given player name doesn't exist in the 
   *       current kill ring.
   *       Throws IllegalStateException if the game is over.
   * post: Takes in the name of player as parameter.
   *       Ignores the case of the name.
   *       Kills player and transfers to graveyard. 
   *       Adds player to the beginning of the graveyard chain.
   */
   public void kill(String name){
      name = name.toLowerCase();
      if(!killRingContains(name)){
         throw new IllegalArgumentException();
      }
      if(gameOver()){
         throw new IllegalStateException();
      }
      AssassinNode current = killRingFront;
      AssassinNode lastPerson = referenceToLast(killRingFront);
      AssassinNode dead = null;
      if(killRingFront.name.toLowerCase().equals(name)){
         killRingFront.killer = lastPerson.name;
         dead = killRingFront;
         killRingFront = killRingFront.next;
      } else {
         while(!current.next.name.toLowerCase().equals(name)){
            current = current.next;
         }
         current.next.killer = current.name;
         dead = current.next;
         current.next = current.next.next;
      }
      addToGraveyard(dead);
   }
   
   /*
   * post : Takes in an assassin node as reference to the current kill ring.
   *        Returns a reference to the last player in the ring.
   */
   private AssassinNode referenceToLast(AssassinNode killRingFront) {
      AssassinNode lastPerson = killRingFront;
      while(lastPerson.next != null){
         lastPerson = lastPerson.next;
      }
      return lastPerson;
   }
   
   /*
   * post: Takes in the name of the dead player as parameter.
   *       Adds player to the beginning of the graveyard chain.
   */
   private void addToGraveyard(AssassinNode dead) {
      dead.next = null;
      if (graveyardFront == null) {
         graveyardFront = dead;
      } else {
         AssassinNode temp = graveyardFront;
         graveyardFront = dead;
         dead.next = temp;
      }
   }
}
