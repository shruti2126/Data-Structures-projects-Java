/*
Name: Shruti Sharma
Class: CSE 143/Section AR
Date: 08/12/2018

This class creates a node used by the HuffmanTree class.
Each node contains the frequency and interger value of a character.
*/
public class HuffmanNode implements Comparable<HuffmanNode> {

  public int frequency; // frequency of character
  public int ch; // integer value of character.
  public HuffmanNode left; //reference to left branch
  public HuffmanNode right; //reference to right branch
  
  /*
  * post: Takes in the frequency, integer value of character, the reference to left and
  *       and right branches of the tree as parameters.
  *       Constructs the huffman node.
  */
  public HuffmanNode(int frequency, int ch, HuffmanNode left, HuffmanNode right){
	  this.frequency = frequency;
	  this.ch = ch;
	  this.left = left;
	  this.right = right;
  }
 
  /*
  * post: Takes in the frequency and integer value of character as parameters.
  *       Constructs the huffman node.
  */
  public HuffmanNode(int frequency, int ch){
      this(frequency, ch, null,  null);
  }
  
  /*
  * post: Takes in another huffman node as parameter.
  *       Returns negative integer if this node has lesser frequency than the other,
  *       returns 1 if the opposite is true and returns 0 if both frequencies are equal.
  */
  public int compareTo(HuffmanNode other){
       return this.frequency - other.frequency;
  }

}