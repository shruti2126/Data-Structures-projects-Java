/*
Name: Shruti Sharma
Class: CSE 143/Section AR
Date: 08/12/2018

This class compresses/encodes text files to binary files (not readable), allows you to write
the tree built to and output file and also decodes an encoded file back to text format
using the huffman coding scheme.
*/
import java.util.*;
import java.io.*;

public class HuffmanTree{

	private HuffmanNode overallRoot; //the root of the huffman tree
	private Queue<HuffmanNode> queue; //priority queue containing leaf nodes with frequencies 
                                     //and character values
   /*
   * post: takes in an array of frequencies and integer character values.
   *       Constructs the initial huffman tree that is used to make code
   *       for the text file.
   */
	public HuffmanTree(int[] count) {
		queue = new PriorityQueue<HuffmanNode>();
		for(int i = 0; i < count.length; i++){
			if(count[i] > 0){
				HuffmanNode node = new HuffmanNode(count[i], i);
				queue.add(node);
  			} 
		} 
		queue.add(new HuffmanNode(1, 256));
		overallRoot = buildTree(overallRoot,  queue);
	}
   
   /*
   * post: Takes the empty overall root of the huffman tree and the priority queue
   *       as parameters.
   *       Builds the intitial huffman tree to be used to make code for the text file.
   *       Returns a overall root of the tree built.
   */
	private HuffmanNode buildTree(HuffmanNode root, Queue<HuffmanNode> queue){
		while(queue.size() > 1){
			HuffmanNode leftNode = queue.remove();
			HuffmanNode rightNode = queue.remove();
			int sum = leftNode.frequency + rightNode.frequency;
			root = new HuffmanNode(sum, 0, leftNode, rightNode);
			queue.add(root);
		}
		return root;
	}
   
   /*
   *post: Takes in the PrintStream object as parameter to help write tree to 
   *      output file in standard format.
   *      Standard format contains a sequence of pairs with first line being character 
   *      integer value and second line being the code (0's and 1's) for the character.
   */
   public void write(PrintStream output){
		write(overallRoot, "", output);    
	}
   
   /*
   * post: Takes in the overall root of the huffman tree to write, an empty string
   *       to build and store the code in and a printStream object to help write tree to 
   *       output file in standard format.
   *       Standard format contains a sequence of pairs with first line being character 
   *       integer value and second line being the code (0's and 1's) for the character.
   */
	private void write(HuffmanNode root, String zerosAndOnes, PrintStream output){
      if(root != null){
   		if(root.left == null && root.right == null){
   			output.println(root.ch);
   			output.println(zerosAndOnes);
   		} else {
   			zerosAndOnes += "0";
   			write(root.left, zerosAndOnes, output);
   			zerosAndOnes = zerosAndOnes.substring(0, zerosAndOnes.length() - 1);
   			zerosAndOnes += "1";
   			write(root.right, zerosAndOnes, output);
   		}
      }   
	}
   
   /*
   * post: Recontructs the tree from a code file containing tree in standard format.
   *       Takes in a Scanner object to help read the code file.
   */
	public HuffmanTree(Scanner input) {
		HuffmanNode root = null;
		while(input.hasNextLine()){
			int value = Integer.parseInt(input.nextLine());
         String code = input.nextLine();			
         root = buildTree(root, value, code);
		}
		overallRoot = root;
	}
   /*
   * post: Takes in the overall root of the huffman tree, the character integer value and
   *       the code (0's and 1's) as parameters.
   *       Reconstructs the huffman tree and returns the new overall root.
   */
	private HuffmanNode buildTree(HuffmanNode root, int value, String code){
		if(code.isEmpty()){
			return new HuffmanNode(-1, value, null, null);
		} 
		if(root == null){
			root = new HuffmanNode(-1, -1, null, null);
		} 
		if(code.charAt(0) == '0'){
			root.left = buildTree(root.left, value, code.substring(1));
		} else {
			root.right = buildTree(root.right, value, code.substring(1));
		}
		return root;
	}
  
   /*
   * post: Decodes the encoded file back to original.
   *       Takes in the BitInputStream object to help read bits from the short file(encoded file),
   *       the printStream object to write characters to an output file and the integer value of
   *       the end-of-file character as parameters.
   */
	public void decode(BitInputStream input, PrintStream output, int eof){
		HuffmanNode root = overallRoot;
      int bit = input.readBit();
		while(root.ch != eof){ 
			if(root.right == null && root.left == null){
				output.print((char)root.ch);
				root = overallRoot;
			} else {
   			if(bit == 0){
   				root = root.left;
   			} else {
   				root = root.right;
   			}
            bit = input.readBit();
   	   }
		} 
	}

}
