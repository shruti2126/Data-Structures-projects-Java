/*
Name: Shruti Sharma
Class: CSE 143/Section AR
Date: 24/10/2018

This class keeps track of a game of Hangman that cheats. It lets you know if the letter 
you guessed is correct or not, how many wrong guesses you have left, the current pattern that 
your guesses have created and all letters you have previously guessed.
*/
import java.util.*;

public class HangmanManager {

   private int guessesLeft; //how many guesses the player has left
   private String currentPattern; //current pattern matching set of words computer is using
   private Set<String> words; //current set of words being used by computer
   private Set<Character> guessed; //set of letters that have been guessed
   
   /*
   * pre: throws IllegalArgumentException if target word length < 1 or the maximum
   *      number of wrong guesses passed is less than 0.
   * post: Takes in a dictionary (with all lowercase letters), the target word length and a 
   *       maximum number of wrong guesses the player is allowed in the game as parameters.
   *       Initializes the game by initializing the current pattern (empty dashes) and the total 
   *       number of wrong guesses available.
  */
   public HangmanManager(Collection<String> dictionary, int length, int max) {
      if (length < 1 || max < 0) {
         throw new IllegalArgumentException();
      }
      guessed = new TreeSet<Character>();
      guessesLeft = max;
      words = new TreeSet<String>();
      for (String word : dictionary) {
         if (word.length() == length) {
            words.add(word);
         }
      }
      currentPattern = "-";
      for(int i = 1; i < length; i++) {
         currentPattern += " -";
      }
   }
   
   /*
   * post: Returns the current set of words being used by the computer.
   */
   public Set<String> words() {
      return words;
   }
   
   /*
   * post: Return the number of guesses left with the player, i.e the number of
   *       of wrong guesses the player can still make.
   */
   public int guessesLeft() {
      return guessesLeft;
   }
   
   /*
   * post: Returns the set of letters that have been guessed previously.
   */
   public Set<Character> guesses() {
      return guessed;
   }
   
   /*
   * pre: throws IllegalStateException if the current set of words the computer is
   *      using is empty.
   * post: Returns the current pattern that the computer has created based on the
   *       player's guesses.
   */
   public String pattern() {
      if (words.isEmpty()) {
         throw new IllegalStateException();
      }
      return currentPattern;
   }
   
   /*
   * pre: throws IllegalStateException if the number guesses left < 1 or if the
   *      the current set of words is empty.
   *      Throws IllegalArgumentException if the letter guessed has already been guessed before.
   * post: Takes the letter guessed by player as a parameter.
   *       Updates the number of guesses left with the player.
   *       Returns the number of occurrences of the guessed letter in the current pattern.
   */
   public int record(char guess) {
      if (guessesLeft < 1 || words.isEmpty()) {
         throw new IllegalStateException();
      }
      if (guessed.contains(guess)) {
         throw new IllegalArgumentException();
      }
      guessed.add(guess);
      Map<String, Set<String>> mapOfWords = createMap();
      currentPattern = getNewPattern(mapOfWords);
      words = mapOfWords.get(currentPattern);
      updateGuesses(guess);
      return countLetters(currentPattern, guess);
   }
  
   /*
   * post: Maps a pattern to subsets of words that coincide with the pattern based on the
   *       player's guess.
   *       Returns the Map.    
   */
   private Map<String, Set<String>> createMap() {
      Map<String, Set<String>> mapOfWords = new TreeMap<String, Set<String>>();
      for (String word : words) {
         String pattern = makePattern(word);
         if(!mapOfWords.containsKey(pattern)){
            mapOfWords.put(pattern, new TreeSet<String>());
         }
         mapOfWords.get(pattern).add(word);
      }
      return mapOfWords;
   }
   
   /*
   * post: Takes in a word as parameter.
   *       Makes a pattern (pattern of dashes and letters) for the word passed in 
   *       based on the player's guesses.
   *       Returns the pattern.
   */
   private String makePattern(String word) {
      String pattern = "";
      String dash = "-";
      for (int i = 0; i < word.length(); i++) {
         char letter = word.charAt(i);
         if (guessed.contains(letter)) {
             pattern += " " + letter;
         } else {
             pattern += " " + dash;
         }
      }
      return pattern.substring(1);
   }
   
   /*
   * post: Takes in a Map containing patterns matched to sets of words.
   *       Returns the pattern that maps to the largest set of words.
   */
   private String getNewPattern(Map<String, Set<String>> mapOfWords) {
      String result = "";
      int count = 0;
      int max = 0;
      for(String pattern : mapOfWords.keySet()) {
         Iterator<String> it = mapOfWords.get(pattern).iterator();
         count = 0;
         while(it.hasNext()) {
            count++;
            it.next();
         }
         if(count > max) {
            max = count;
            result = pattern;
         }
      }
      return result;
   }
   
   /*
   * post: Takes in the guessed letter in as parameter.
   *       Updates the number of wrong guesses the player has left to make.
   */
   private void updateGuesses(char guess) {
      boolean isPresent = false;
      for(String word : words) {
         if(word.indexOf(guess) != -1) {
            isPresent = true;
         }
      }
      if(!isPresent) {
         guessesLeft--;
      }
   }
   
   /*
   * post: Takes the current pattern in use and the guessed letter as parameters.
   *       Returns the number of occurrences of the guessed letter in the current pattern.
   */
   private int countLetters(String currentPattern, char guess) {
      int count = 0;
      for(int i = 0; i < currentPattern.length(); i++) {
         if(currentPattern.charAt(i) == guess) {
            count++;
         }
      }
      return count;
   }
}
