/* CS400 Project Name - p4 
 * Name: Shruti Sharma 
 * Email: sharma224@wisc.edu
 * CS400 LEC001
*/
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Filename:   Graph.java
 * Project:    p4
 * Authors:    Shruti Sharma
 * 
 * Directed and unweighted graph implementation
 */

public class Graph implements GraphADT {
	
	private Hashtable<String, ArrayList<String>> AL; // Adjacency list 
	//stores vertices as keys and its successors in a list
	
	/*
	 * Default no-argument constructor
	 */ 
	public Graph() {
		AL = new Hashtable<String, ArrayList<String>>();
	}

	@Override
	 /**
     * Add new vertex to the graph.
     *
     * If vertex is null or already exists,
     * method ends without adding a vertex or 
     * throwing an exception.
     * 
     * Valid argument conditions:
     * 1. vertex is non-null
     * 2. vertex is not already in the graph 
     * 
     * @param vertex the vertex to be added
     */
	public void addVertex(String vertex) {
		if(vertex != null && !AL.contains(vertex)) {
			AL.put(vertex, new ArrayList<String>());
		}
	}

	@Override
	/**
     * Remove a vertex and all associated 
     * edges from the graph.
     * 
     * If vertex is null or does not exist,
     * method ends without removing a vertex, edges, 
     * or throwing an exception.
     * 
     * Valid argument conditions:
     * 1. vertex is non-null
     * 2. vertex is not already in the graph 
     *  
     * @param vertex the vertex to be removed
     */
	public void removeVertex(String vertex) {
		if(vertex != null && AL.containsKey(vertex)) {
			AL.remove(vertex);
		}
		for(String key : AL.keySet()) {
			if(AL.get(key).contains(vertex)) {
				AL.get(key).remove(vertex);
			}
		}
	}

	@Override
	 /**
     * Add the edge from vertex1 to vertex2
     * to this graph.  (edge is directed and unweighted)
     * 
     * If either vertex does not exist,
     * VERTEX IS ADDED and then edge is created.
     * No exception is thrown.
     *
     * If the edge exists in the graph,
     * no edge is added and no exception is thrown.
     * 
     * Valid argument conditions:
     * 1. neither vertex is null
     * 2. both vertices are in the graph 
     * 3. the edge is not in the graph
     *  
     * @param vertex1 the first vertex (src)
     * @param vertex2 the second vertex (dst)
     */
	public void addEdge(String vertex1, String vertex2) {
		if(AL.containsKey(vertex1) && AL.containsKey(vertex2)) {//if both vertices exist
			ArrayList<String> list = AL.get(vertex1);
			list.add(vertex2);
			AL.put(vertex1, list);
		}else if(!AL.containsKey(vertex1) && AL.containsKey(vertex2)) { //if vertex1 doesn't exist but vertex2 exists
			ArrayList<String> list = new ArrayList<String>();
			list.add(vertex2);
			AL.put(vertex1, list);
		} else if(AL.containsKey(vertex1) && !AL.containsKey(vertex2)) { //if vertex1 exists but vertex2 doesn't
			ArrayList<String> edges = AL.get(vertex1); // get list of adj edges of vertex 1
			edges.add(vertex2);
			AL.put(vertex2, new ArrayList<String>()); 
		} else { //If neither vertex1 nor vertex2 exists
			ArrayList<String> list = new ArrayList<String>();
			list.add(vertex2);
			AL.put(vertex1, list); 
			AL.put(vertex2, new ArrayList<String>()); 
		}
	}

	@Override
	/**
     * Remove the edge from vertex1 to vertex2
     * from this graph.  (edge is directed and unweighted)
     * If either vertex does not exist,
     * or if an edge from vertex1 to vertex2 does not exist,
     * no edge is removed and no exception is thrown.
     * 
     * Valid argument conditions:
     * 1. neither vertex is null
     * 2. both vertices are in the graph 
     * 3. the edge from vertex1 to vertex2 is in the graph
     *  
     * @param vertex1 the first vertex
     * @param vertex2 the second vertex
     */
	public void removeEdge(String vertex1, String vertex2) {
		if(AL.containsKey(vertex1) && AL.containsKey(vertex2) && !vertex1.equals(vertex2)) {// both vertices exist
			if(AL.get(vertex1).contains(vertex2)) {//if there is an edge from vertex1 to vertex2
				AL.get(vertex1).remove(vertex2); //remove vertex 2 from list of adj vertices
			}
		}
		
	}

	@Override
	/**
     * Returns a Set that contains all the vertices
     * 
     * @return a Set<String> which contains all the vertices in the graph
     */
	public Set<String> getAllVertices() {
		Set<String> set = new HashSet<String>();
		for(String vertex : AL.keySet()) {
			set.add(vertex);
		}
		return set;
	}

	@Override
	/**
     * Get all the neighbor (adjacent-dependencies) of a vertex
     * 
     * For the example graph, A->[B, C], D->[A, B] 
     *     getAdjacentVerticesOf(A) should return [B, C]. 
     * 
     * In terms of packages, this list contains the immediate 
     * dependencies of A and depending on your graph structure, 
     * this could be either the predecessors or successors of A.
     * 
     * @param vertex the specified vertex
     * @return an List<String> of all the adjacent vertices for specified vertex
     */
	public List<String> getAdjacentVerticesOf(String vertex) {
		List<String> adjVertices = new ArrayList<String>();
	    for(String edge : AL.get(vertex)) {
	    	adjVertices.add(edge);
	    }
		return adjVertices;
	}

	@Override
    /**
     * Returns the number of edges in this graph.
     * @return number of edges in the graph.
     */
	public int size() {
		int size = 0;
		for(String vertex : AL.keySet()) {
			size += AL.get(vertex).size();
		}
		return size;
	}

	@Override
	/**
     * Returns the number of vertices in this graph.
     * @return number of vertices in graph.
     */
	public int order() {
		return AL.keySet().size();
	}
}

