/* CS400 Project Name - p4 
 * Name: Shruti Sharma 
 * Email: sharma224@wisc.edu
 * CS400 LEC001
*/
/*
 * This class perform Tests on the Graph.Java class.
 */
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class GraphTest{

    protected Graph graph;
    
    // TODO: add code that runs before each test method
    @Before
    public void setUp() throws Exception {
    	graph = new Graph();
    }

    // TODO: add code that runs after each test method
    @After
    public void tearDown() throws Exception {

    }
    
    @Test
    public void removeNotNullVertex() {
        graph.addVertex("1");
        graph.addEdge("1", "2");
        assertEquals(2, graph.order()); // # vertices
        assertEquals(1, graph.size()); // # edges
        graph.removeVertex("2");
        assertEquals(1, graph.order()); // # vertices
        assertEquals(0, graph.size()); // #edges
    }
    
    @Test
    public void addNullVertex() {
    	graph.addVertex(null);
    	if(graph.order() != 0) {
    		fail("Null vertex was added.");
    	}
    }
    
    @Test
    public void addDuplicateVertex() {
    	graph.addVertex("1");
        graph.addVertex("1");
    	if(graph.order() == 2) {
    		fail("Duplicate value added.");
    	}
    	
    }
    
    @Test
    public void addEdgeIfAnyOfVerticesDontExist() {
    	graph.addEdge("1", "2");
    	if(graph.size() != 1) {
    		fail("edge not added");
    	}
    	if(graph.order() != 2) {
    		fail("both vertices not added!");
    	}
    }
    @Test
    public void removeEdgeIfBothVerticesExist() {
    	try {
    		graph.removeEdge("1", "2");
    	}catch (Exception e) {
    		fail("No exception should be thrown if none of the vertices exist.");
    	}
    }
}