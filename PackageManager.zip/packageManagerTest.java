/* CS400 Project Name - p4 
 * Name: Shruti Sharma 
 * Email: sharma224@wisc.edu
 * CS400 LEC001
*/
/*
 * This class performs JUnit tests on PackageManager Class
 */
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.json.simple.parser.ParseException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class packageManagerTest{

    protected PackageManager packageManager;
    
    // TODO: add code that runs before each test method
    @Before
    public void setUp() throws Exception {
    	packageManager = new PackageManager();
    }

    // TODO: add code that runs after each test method
    @After
    public void tearDown() throws Exception {

    }
    
    @Test
    public void noCycleTest() {
    	try {
			packageManager.constructGraph("jsonTest1.json");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	try {
    		List<String> list = packageManager.getInstallationOrderForAllPackages();
    	} catch(CycleException e) {
    		fail("Cycle Exception caught");
    	}
    }
    
    @Test 
    public void cycleTest() {
    	try {
			packageManager.constructGraph("jsonTest2.json");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	try {
    		List<String> list = packageManager.getInstallationOrderForAllPackages();
    		fail("Cycle Exception should have been caught");
    	} catch(CycleException e) {
    		
    	}
    }
    
    @Test
    public void cycleInTwoComponents() {
    	try {
			packageManager.constructGraph("jsonTest3.json");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	try {
    		List<String> list = packageManager.getInstallationOrderForAllPackages();
    		fail("Cycle Exception should have been caught");
    	} catch(CycleException e) {
    		
    	}
    }
    
    @Test
    public void testInstallationOrder() {
    	try {
			packageManager.constructGraph("valid.json");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	try {
    		List<String> correctOrder = new ArrayList<String>();
    		correctOrder.add("C");
    		correctOrder.add("D");
    		correctOrder.add("B");
    		correctOrder.add("E");
    		correctOrder.add("A");
    		List<String> expected = packageManager.getInstallationOrderForAllPackages();
    		System.out.println(expected);
    		for(int i = 0; i < 5; i++) {
    			if(!expected.get(i).equals(correctOrder.get(i))) {
    				fail("installation order for all packages not correct");
    			}
    		}
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }
    
    @Test
    public void testInstallationOrderWithCycleException() {
    	try {
			packageManager.constructGraph("jsonTest2.json");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	try {
    		List<String> expected = packageManager.getInstallationOrderForAllPackages();
    		fail("should have caught cycle Exception");
    	} catch (CycleException e) {
    		
    	}
    }
    
    @Test
    public void installationOrderForParticularPackage() {
    	try {
			packageManager.constructGraph("jsonTest2.json");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	try {
    		List<String> installOrder = packageManager.getInstallationOrder("C");
    		if(!installOrder.get(0).equals("D")) {
    			fail("Installation order for particular package not working");
    		}
    	} catch (Exception e) {
    		
    	}
    }
    
    @Test
    public void testPackageWithMaxDependencies() {
    	try {
			packageManager.constructGraph("valid.json");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	try {
    		if(!packageManager.getPackageWithMaxDependencies().equals("A")) {
    			fail(" expected max dependency package is A but got " + packageManager.getPackageWithMaxDependencies());
    		}
    	} catch(Exception e) {
    		fail("Exception thrown");
    	}
    }
    
}
