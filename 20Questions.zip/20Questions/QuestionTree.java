/*
Name: Shruti Sharma
Class: CSE 143/section AR
Date: 11/22/2018

This class lets you play a guessing game with the computer. Each round of the game 
begins by you thinking of an object while the computer tries to guess your object by 
asking you a series of yes or no questions until it wins or loses. These series of 
questions and answers are stored in a tree that you can read from and store in a file 
in case you want to use the tree again.
*/

import java.io.*;
import java.util.*;

public class QuestionTree {
   
   private QuestionNode overallRoot; //the top of the question tree
   private Scanner console; //the scanner object to read input text files
   
   /*
   * post: Initialises the game by guessing the first object to be computer.
   */
   public QuestionTree() {
      console = new Scanner(System.in);
      overallRoot = new QuestionNode("computer");
   }
   
   /*
   * post: replaces the current tree with a new tree from a file.
   *       Takes in the Scanner linked to the file as a parameter, to be able to read it.
   */
   public void read(Scanner input) {
      overallRoot = readTree(input);
   }
   
   /*
   * post: Replaces the current tree with a new tree from a file.
   *       Takes in Scanner linked to the file as a parameter, to be able to read it.
   *       Returns the overall root of the new question tree.
   */
   private QuestionNode readTree(Scanner input) {
      QuestionNode node = null;
      if (input.hasNextLine()){
         if (input.nextLine().startsWith("A:")) {
            node = new QuestionNode(input.nextLine());
         } else {
            node = new QuestionNode(input.nextLine(), readTree(input), readTree(input));
         }
      }
      return node;
   }
   
   /*
   * post: Stores the current tree into a text output file in a format like:
   *       [Q: Is it an animal?  A: frog] but Q:, A: and the text are each written on
   *       new lines. 
   *       Takes in the Print stream object which allows user to write to the output file
   *       as parameter.  
   */
   public void write(PrintStream output) {
      write(output, overallRoot);
   }
   
   /*
   * post: Stores the current tree into a text output file in a format like:
   *       [Q:Is it an animal?  A:frog] but Q:, A: and the text are each written on
   *       new lines. 
   *       Takes in the Print stream object which allows user to write to the output file 
   *       and the overall root of the tree as parameters. 
   */
   private void write(PrintStream output, QuestionNode node) {
      if (node.yes == null && node.no == null) {
         output.println("A:");
         output.println(node.text);
      } else {
         output.println("Q:");
         output.println(node.text);
         write(output, node.yes);
         write(output, node.no);
      }
   }
   
   /*
   * post: Asks a series of yes/no questions until it either guesses your
   *       object correctly or fails, in which case it requests you to provide a 
   *       question to distinguish its guessed object from others to expand the 
   *       question tree.
   */
   public void askQuestions() {
      overallRoot = askQuestions(overallRoot);
   }
   
   /*
   * post: Asks a series of yes/no questions until it either guesses your
   *       object correctly or fails, in which case it requests you to provide a 
   *       question to distinguish its guessed object from others. This expands the 
   *       question tree.
   *       Takes in the overall root of the question tree
   *       Returns the overall root of the question tree (the new overall root if expanded).
   */
   private QuestionNode askQuestions(QuestionNode node) {
      if (node.yes == null && node.no == null) {
         if (yesTo("Would your object happen to be " + node.text + "?")) {
            System.out.println("Great, I got it right!");
         } else {
            node = addQuestionToTree(node);
         }
      } else {
         if (yesTo(node.text)) {
            node.yes = askQuestions(node.yes);
         } else {
            node.no = askQuestions(node.no);
         }
      }
      return node;
   }
   
   /*
   * post: Expands the question tree when computer loses the game by
   *       adding a new question and answer. 
   *       Takes the overall root of the tree as a parameter. 
   *       Returns the the overall root of the expanded tree.
   */
   private QuestionNode addQuestionToTree(QuestionNode node){
      System.out.print("What is the name of your object? ");
      QuestionNode answerNode = new QuestionNode (console.nextLine());
      System.out.println("Please give me a yes/no question that");
      System.out.println("distinguishes between your object");
      System.out.println("and mine--> ");
      String question = console.nextLine();
      if (yesTo("And what is the answer for your object?")) {
         return new QuestionNode(question, answerNode, node);
      } else {
         return new QuestionNode(question, node, answerNode);
      }
   }
   
   /*
   * post: Asks the given question until you respond with a 'y' (for yes)
   *      or 'n' (for no).
   *      Takes in the the prompt/question in as a parameter. 
   *      Returns true if you answer yes and false if no.
   */
   public boolean yesTo(String prompt) {
      System.out.print(prompt + " (y/n)? ");
      String response = console.nextLine().trim().toLowerCase();
      while (!response.equals("y") && !response.equals("n")) {
         System.out.println("Please answer y or n.");
         System.out.print(prompt + " (y/n)? ");
         response = console.nextLine().trim().toLowerCase();
      }
      return response.equals("y");
   }
}
