/*
Name: Shruti Sharma
Class: CSE 143/section AR
Date: 11/22/2018

This class stores a question and its possible yes and no answers in text form and is called a 
QuestionNode that is used by the QuestionTree class.
*/
public class QuestionNode {
   
   public QuestionNode yes; //node in left branch of question tree
   public QuestionNode no;  //node in right branch of question tree
   public String text;      //the text the node contains
   
   /*
   * post: Constructs a question node with given text.
   */
   public QuestionNode(String text) {
      this(text, null, null);
   }
   
   /*
   * post: Constructs a question node with given text, question node for left branch and 
   *        question node for right branch (yes and no branches respectively).
   */
   public QuestionNode(String text, QuestionNode yes, QuestionNode no) {
      this.text = text;
      this.yes = yes;
      this.no = no;
   }
}