package grammarSolver;

import java.util.*;
public class GrammarSolver {
  private SortedMap<String, List<String>> grammarMap;
  
  //pre : throws IllegalArgumentException if grammar is empty or
  //of there are two or more entries in the grammar for the same
  //non-terminal.
  //post : Stores the grammar appropriately for use later.
  public GrammarSolver(List<String> grammar) {
   if(grammar.isEmpty() /* OR two or more entries for nonterminal*/){
     throw new IllegalArgumentException();
   }
   grammarMap =  new TreeMap<String, List<String>>();
   for(String s : grammar){
	     String[] parts = s.split("::=");
	     String nonTerminal = parts[0].trim();
	     String[] rules = parts[1].split("[|]");
	     List<String> terminals = new ArrayList<String>();
	     for(String element : rules){
	       terminals.add(element); 
	     }
	     grammarMap.put(nonTerminal, terminals);
	  }
   }
    
   //post : returns true if the given symbol is a non-terminal of the grammar.
   //Returns false otherwise.
   public boolean grammarContains(String symbol){
     return grammarMap.containsKey(symbol);
   }
   
    //pre : throw an IllegalArgumentException if the grammar does not contain
   //the given non-terminal symbol or if the number of times is less than 0.
   //post : generates and returns the given number of occurences of
   //the given symbol.
   public String[] generate(String symbol, int times){
	  if(!grammarMap.containsKey(symbol) || times < 0){
		 throw new IllegalArgumentException();
	  } 
      String[] result = new String[times];
      for (int i = 0; i < times; i++) {
    	 String sentence = generateHelper(symbol);
	     result[i] = sentence;
	   }   
	  return result; 
	}      
  
    private String generateHelper(String symbol){
       String sentence = "";
       if(!grammarMap.containsKey(symbol)) {
    	  return symbol;
       }
       Random rand = new Random();
       List<String> list = grammarMap.get(symbol);
       int num = rand.nextInt(list.size());
       String terminal = list.get(num);
       String[] parts = terminal.split("[ \t]+");
       for(int i = 0; i < parts.length; i++){
	       String tempText = generateHelper(parts[i]);
	       if(!tempText.contains("<")){
	          sentence += tempText + " ";
	       }    
        }
       return sentence.trim();
     }
  
   public String getSymbols(){
    Set<String> nonTerminals = new TreeSet<String>();
    for (String key : grammarMap.keySet() ) {
        nonTerminals.add(key);
    }
    return nonTerminals.toString();
   }
  
 }
 
